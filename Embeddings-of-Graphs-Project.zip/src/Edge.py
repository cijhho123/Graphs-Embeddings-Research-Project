class Edge:
    def __init__(self, u, v):
        self.first = u
        self.second = v
